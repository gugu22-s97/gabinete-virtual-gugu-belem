const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const XLSX = require('xlsx');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

const SECRET = "GV_GUGU_BELEM_2026";

const db = new sqlite3.Database('./eleitores.db');

db.run(`
CREATE TABLE IF NOT EXISTS demandas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  protocolo TEXT,
  nome TEXT,
  apelido TEXT,
  endereco TEXT,
  telefone TEXT,
  data_nascimento TEXT,
  demanda TEXT,
  status TEXT DEFAULT 'Recebida',
  consentimento INTEGER,
  data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
)
`);

function gerarProtocolo(id) {
  const ano = new Date().getFullYear();
  return `GV-${ano}-${String(id).padStart(4, '0')}`;
}

app.post('/login', (req, res) => {
  if (req.body.senha === "123456") {
    const token = jwt.sign({ admin: true }, SECRET);
    return res.json({ token });
  }
  res.status(401).json({ erro: "Senha inválida" });
});

function autenticar(req, res, next) {
  const token = req.headers.authorization;
  if (!token) return res.status(403).json({ erro: "Acesso negado" });
  try {
    jwt.verify(token, SECRET);
    next();
  } catch {
    res.status(401).json({ erro: "Token inválido" });
  }
}

app.post('/cadastro', (req, res) => {
  const { nome, apelido, endereco, telefone, data_nascimento, demanda, consentimento } = req.body;
  if (!consentimento) {
    return res.status(400).json({ erro: "Aceite da LGPD obrigatório" });
  }

  db.run(`
    INSERT INTO demandas (nome, apelido, endereco, telefone, data_nascimento, demanda, consentimento)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `, [nome, apelido, endereco, telefone, data_nascimento, demanda, 1],
  function(err) {
    if (err) return res.status(500).json({ erro: err.message });
    const protocolo = gerarProtocolo(this.lastID);
    db.run(`UPDATE demandas SET protocolo = ? WHERE id = ?`,
      [protocolo, this.lastID]);
    res.json({ mensagem: "Demanda registrada com sucesso!", protocolo });
  });
});

app.get('/demandas', autenticar, (req, res) => {
  db.all("SELECT * FROM demandas ORDER BY id DESC", [], (err, rows) => {
    res.json(rows);
  });
});

app.put('/status/:id', autenticar, (req, res) => {
  db.run("UPDATE demandas SET status = ? WHERE id = ?",
    [req.body.status, req.params.id],
    function() {
      res.json({ mensagem: "Status atualizado" });
    });
});

app.get('/exportar', autenticar, (req, res) => {
  db.all("SELECT * FROM demandas", [], (err, rows) => {
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Demandas");
    XLSX.writeFile(wb, "demandas.xlsx");
    res.download("demandas.xlsx");
  });
});

app.listen(3000, () => console.log("Servidor rodando na porta 3000"));
